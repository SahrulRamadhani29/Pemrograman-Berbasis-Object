package Polimorfisme;

public class Tester1 {
    public static void main(String[] args) {
        PermanentEmployee pEmp = new PermanentEmployee("Dedik ", 500);
        InternshipEmployee iEmp = new InternshipEmployee("Sunarto ", 5 );
        ElectricityBill eBill = new ElectricityBill(5, "R-1");

        Employee e;
        Payable p;
        e = pEmp;
        e = iEmp;
        p = pEmp;
        p = eBill;
        
        System.out.println("===Permanent Employee===");
        System.out.println(pEmp.getEmployeeInfo());
        System.out.println("Payment Amount: " + pEmp.getPaymentAmount());
        System.out.println("===Electricity Bill===");
        System.out.println(eBill.getBillInfo());
        System.out.println("Payment Amount: " + eBill.getPaymentAmount());

        System.out.println("===Internship Employee===");
        System.out.println(iEmp.getEmployeeInfo());

    }
}
