package Polimorfisme;
public class Pisang extends Buah {

    public Pisang(){
        Rasa = "Sepet";
    }

    public void TampilkanKulit(){
        System.out.println("Kulit pisang berwarna kuning");
    }

    public void kandunganAir (){
        System.out.println("Kandungan air pisang adalah 100%");
    }
}
