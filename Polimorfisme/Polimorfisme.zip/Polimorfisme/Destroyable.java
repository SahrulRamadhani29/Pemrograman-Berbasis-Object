package Polimorfisme;

public interface Destroyable {
    void destroyed();
}
