package Polimorfisme;

public class Buah {
        public String Rasa;
}
