package Polimorfisme;
public interface Payable {
    public int getPaymentAmount();
}