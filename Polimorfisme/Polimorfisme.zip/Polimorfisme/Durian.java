package Polimorfisme;
public class Durian extends Buah {
    public Durian(){
        Rasa = "Manis dan Legit";
    }

    public void TampilkanDurinya(){
        System.out.println("Durian memiliki duri yang tajam");
    }

    public void kandunganAir (){
        System.out.println("Kandungan air durian adalah 80%");
    }
    
}
