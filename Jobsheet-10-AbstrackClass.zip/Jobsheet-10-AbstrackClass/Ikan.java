// Sekarang class Ikan menjadi abstract
public abstract class Ikan extends Hewan {

    // deklarasikan kembali abstract method bergerak()
    public abstract void bergerak();
}
