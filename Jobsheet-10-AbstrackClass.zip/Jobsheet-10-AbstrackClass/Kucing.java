
class Kucing extends Hewan{

    @Override
    public void bergerak() {
    System.out.println("Berjalan dengan KAKI, \"Tap..tap..\"");
        
    }
    
}
