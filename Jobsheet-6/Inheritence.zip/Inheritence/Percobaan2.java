public class Percobaan2 {
    public static void main(String[] args) {
        ClassB2 hitung = new ClassB2();
        hitung.setX(20);
        hitung.setY(30);
        hitung.setZ(5);
        hitung.getNilai();
        hitung.getNilaiZ();
        hitung.getJumlah();
        
    }
}
