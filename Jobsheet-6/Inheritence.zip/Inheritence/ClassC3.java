public class ClassC3 extends ClassB3 {
    ClassC3(){
        super();    
        System.out.println("Konstruktor C dijalankan");
    }
    
}
