public class Percobaan1 {
    
    public static void main(String[] args) {
    
        ClassB hitung = new ClassB();
        hitung.x = 20;
        hitung.y= 30;
        hitung.z = 5;

        hitung.getNilai();
        hitung.getNilaiZ();
        hitung.getJumlah();
}
}
