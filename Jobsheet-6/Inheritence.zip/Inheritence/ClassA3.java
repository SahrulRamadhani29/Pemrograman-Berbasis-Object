public class ClassA3 {
    ClassA3(){
        System.out.println("Konstruktor A dijalankan");
    }
}
