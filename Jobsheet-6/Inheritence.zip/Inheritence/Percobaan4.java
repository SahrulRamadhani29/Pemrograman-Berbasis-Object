public class Percobaan4 {
    public static void main(String[] args) {
        ClassC3 test = new ClassC3();
    }
}
