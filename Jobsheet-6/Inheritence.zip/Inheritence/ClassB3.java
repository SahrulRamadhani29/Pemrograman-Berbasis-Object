public class ClassB3 extends ClassA3 {
    ClassB3(){
        System.out.println("Konstruktor B dijalankan");
    }
    
}
