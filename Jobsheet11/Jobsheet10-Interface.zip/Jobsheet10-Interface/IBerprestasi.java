package Jobsheet11;

public interface IBerprestasi {

    public abstract void menjuaraiKompetisi();
    public abstract void membuatPublikasiIlmiah();
} 