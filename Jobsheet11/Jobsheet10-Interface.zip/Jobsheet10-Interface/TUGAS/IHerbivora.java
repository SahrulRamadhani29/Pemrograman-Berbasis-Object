package Jobsheet11.TUGAS;

public interface IHerbivora {
    void displayMakanan();
}
