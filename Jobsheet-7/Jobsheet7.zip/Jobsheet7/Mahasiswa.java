public class Mahasiswa extends Manusia{
    public void makan (){
        System.out.println("Mahasiswa Sedang Makan");
    }

    public void tidur (){
        System.out.println("Mahasiswa Sedang tidur");
    }
}
