public class Piranha extends Ikan {
    public void swim (){
        System.out.println("PIranha bisa makan daging");
    }
    }
