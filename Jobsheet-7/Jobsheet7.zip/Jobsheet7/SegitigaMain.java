public interface SegitigaMain {
    public static void main(String[] args) {
        Segitiga sg1 = new Segitiga();

        sg1.totalSudut(60);
        sg1.totalSudut(60, 30);

        sg1.keliling(3,5,7);

        sg1.keliling(6, 8);
    }
}
