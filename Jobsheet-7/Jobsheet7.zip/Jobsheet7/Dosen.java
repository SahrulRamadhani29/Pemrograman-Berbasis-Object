public class Dosen extends Manusia {
    public void makan (){
        System.out.println("Dosen Sedang Makan");
    }

    public void lembur (){
        System.out.println("Dosen Sedang Lembur");
    }
}
