public class Manusia {
    public void bernafas(){
        System.out.println("Manusia Sedang Bernafas");
    }

    public void makan(){
        System.out.println("Manusia Sedang Makan");
    }
}
